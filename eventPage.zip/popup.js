$(function(){

    chrome.storage.sync.get(['total','limit'],function(calorie){
        $('#total').text(calorie.total);
        $('#limit').text(calorie.limit);
    });

    $('#spendAmount').click(function(){
        chrome.storage.sync.get(['total', 'limit'],function(calorie){
            var newTotal = 0;
            if (calorie.total){
                newTotal += parseInt(calorie.total);
            }

            var amount = $('#amount').val();
            if (amount){
                newTotal += parseInt(amount);
            }

            chrome.storage.sync.set({'total': newTotal}, function(){               
                if (amount && newTotal >= calorie.limit){
                    var notifOptions = {
                        type: "basic",
                        iconUrl: "icon48.png",
                        title: "Calorie Limit reached!",
                        message: "Oh no, you've reached your calorie limit."
                };
                chrome.notifications.create('limitNotif', notifOptions);

            }
            });
            $('#total').text(newTotal);
            $('#amount').val('');

           

        });
    });
});